import random, time

CardValues = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
User_Cards = []

def NewCard():
  User_GivenCard = random.choice(CardValues)
  User_Cards.append(User_GivenCard)

def User_Round():

  #First two cards
  NewCard()
  NewCard()
  print(" > > > YOUR FIRST TWO CARDS")
  print()
  time.sleep(1)
  print("Your cards : " + str(User_Cards))
  print()
  print("Total value : " + str(sum(User_Cards)))
  print()

  # While Loop for Hit and Stay

  while sum(User_Cards) < 21:
    time.sleep(1)
    HitValue = input("Do you want to hit or stay: (hit/stay) ")
    print()
    print()
    if HitValue == "hit":
      time.sleep(1)
      print(" > > > YOU TOOK A HIT")
      NewCard()
      time.sleep(1)
      print()
      print("Your cards : " + str(User_Cards))
      print()
      print("Total value : " + str(sum(User_Cards)))
      print()

    elif HitValue == "stay":
      time.sleep(1)
      print(" - - - YOU STAYED")
      time.sleep(1)
      print()
      print("Final cards : " + str(User_Cards))
      print()
      print("Final value : " + str(sum(User_Cards)))
      print()
      break

User_Round()