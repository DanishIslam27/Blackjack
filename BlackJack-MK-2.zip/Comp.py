import random, time

CardValues = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
Comp_TrueCards = []
UKC_List = ["Unknown"]

def NewCard():
  Comp_GivenCard = random.choice(CardValues)
  Comp_TrueCards.append(Comp_GivenCard)

def Comp_Round():

  #First two cards
  print(" > > > COMP FIRST TWO CARDS")
  print()
  NewCard()
  NewCard()
  time.sleep(1)
  print("Comp Cards : " + str(UKC_List + Comp_TrueCards[1:]))
  print()
  #print("Comp Total value : " + str(sum(Comp_TrueCards)))
  #print()

  while sum(Comp_TrueCards) < 17:
    time.sleep(1)
    print()
    print(" > > > COMP TOOK A HIT")
    time.sleep(1)
    NewCard()
    print()
    print("Comp Cards : " + str(UKC_List + Comp_TrueCards[1:]))
    print()
    print()
    #print("Comp Total value : " + str(sum(Comp_TrueCards)))
    #print()
  
  time.sleep(1)
  print()
  print(" - - - COMP TOOK A STAND")
  print()
  print("Comp Cards : " + str(UKC_List + Comp_TrueCards[1:]))


Comp_Round()