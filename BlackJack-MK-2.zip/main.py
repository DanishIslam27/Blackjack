import time

print("IT IS THE COMPUTER'S TURN")
print("-------------------------")
print()
print()
time.sleep(1)

import Comp
time.sleep(1)

C = sum((Comp.Comp_TrueCards))

print()
print()
print()
print("IT IS YOUR TURN NOW")
print("-------------------")
time.sleep(1)
print()
print()

import User

U = sum((User.User_Cards))
time.sleep(1)

print()
print()
print()
time.sleep(1)
print("BIG REVEAL")
print("-------------------")
time.sleep(1)
#print()
#print()

print("   YOUR FINAL SCORE : " + str(U) + "   COMP FINAL SCORE : " + str(C))
print()
time.sleep(1)


if U <= 21 and U > C:
  print("   You win!")
elif U > 21 and C > 21:
  print("   You both busted!")
elif C <= 21 and C > U:
  print("   The computer wins!")
elif C > 21 and U <= 21:
  print("   You win!")
elif U > 21 and C <= 21:
  print("   The computer wins!")
elif C == U:
  print("   That's a draw...")

print()
print()
print()